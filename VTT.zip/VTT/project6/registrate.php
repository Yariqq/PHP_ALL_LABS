<?php
	require_once('Template.php');
	$parse->getTemplate('html/success_reg.html');
	$parse->setTemplate('{NAME}', $_POST['u_nicename']);
	$parse->tmpParse();
	echo $parse->template;