<?php
class Template
{
	private $replacingElements = [];
    public $template;

    public function getTemplate($tpl_name)
	{
      if(empty($tpl_name) || !file_exists($tpl_name))
	  {
		  return false;
	  }
      else
	  {
		  $this->template  = file_get_contents($tpl_name);
	  }
	}
	
    public function setTemplate($key,$var)
	{
		$this->replacingElements[$key] = $var;
	}
	
    public function tmpParse()
	{
		foreach($this->replacingElements as $itemToReplace => $new_item)
		{
			$this->template = str_replace($itemToReplace, $new_item, $this->template);
		}
	}
}

$parse = new Template;