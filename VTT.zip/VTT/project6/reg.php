<?php
	require_once('Template.php');
	$parse->getTemplate('html/success.html');
	$parse->setTemplate('{NAME}', $_POST['u_nicename']);
	$parse->tmpParse();
	echo $parse->template;