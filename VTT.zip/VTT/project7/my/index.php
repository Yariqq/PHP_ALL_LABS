<?php
	
	include('lab2.html');
	if (isset($_POST['setcookie']))
	{
		$name = $_POST['namecookie'];
		$value = $_POST['valuecookie'];
		$time = $_POST['time'];
		if ($name != "" && $value != "" && $time != "")
		{
			setcookie($name, $value, time() + $time);
			echo "Cookie has been set";
		}
		else
		{
			echo "Please, fill empty fields.";
		}
	}
	if (isset($_POST['updatebtn']))
	{
		print_r($_COOKIE);	
	}