<?php

$someStr = "Hello, меня зовут Yarik and i'm 18 лет.";

$str = preg_replace_callback('/([a-z]+)/i', 'eng', $someStr); 
$str = preg_replace_callback('/([а-яё]+)/ui', 'rus', $str);
$str = preg_replace_callback('/([0-9]+)/', 'num', $str);
echo $someStr;
echo '<br>';
echo $str;

function eng($template)
{
	return '<span style="color: blue">'.($template[0]).'</span>'; 
}

function rus($template)
{
	return '<span style="color: red">'.($template[0]).'</span>'; 
}

function num($template)
{
	return '<span style="color: green">'.($template[0]).'</span>'; 
}

?>
	