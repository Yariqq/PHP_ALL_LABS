<!DOCTYPE html>
<html>
<head>
	<title>Birth</title>
</head>
<body>
	<p>Необходимо ввести дату рождения в виде: "Год-Месяц-День". Например: "1990-06-12"</p>
	<form method="post" action="index.php">
		<input type="text" name="lbl">	
		<input type="submit" name="but" value="Ok">
	</form>

	<?php
	if (isset($_POST['but']))
	{
		try
		{
			$born = new DateTime($_POST['lbl']);
			$age = $born -> diff(new DateTime) -> format('%y лет, %m месяцев, %d дня/ей.');
			print_r($age);
		} 
		catch (Exception $e)
		{
    		print_r("Проверьте корректность ввода.");
		}
		
	}
	?>
	
</body>
</html>
