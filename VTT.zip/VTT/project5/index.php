<!DOCTYPE html>
<html>
<head>
	<title>First Database</title>
</head>
<body>
	<p><h3><strong>Добавить запись в БД: </strong></h3></p>
	<form method="post" action="index.php">
		<input type="text" name="lbl2" placeholder = "FIO"><br><br>
		<input type="text" name="lbl3" placeholder = "Age"><br><br>
		<input type="text" name="lbl4" placeholder = "Country"><br><br>	
		<input type="submit" name="but" value="Add"><br><br><br>
	</form>

	<p><h3><strong>Удалить запись из БД: </strong></h3></p>
	<form method="post" action="index.php">
		<input type="text" name="lblID" placeholder = "id"><br><br>
		<input type="submit" name="but1" value="Delete"><br><br><br>
	</form>

	<p><h3><strong>Редактировать запись в БД: </strong></h3></p>
	<form method="post" action="index.php">
		<input type="text" name="lblIDToChange" placeholder = "id"><br><br>
		<input type="text" name="lblFIOToChange" placeholder = "FIO"><br><br>
		<input type="text" name="lblAgeToChange" placeholder = "Age"><br><br>
		<input type="text" name="lblCountryToChange" placeholder = "Country"><br><br>
		<input type="submit" name="but2" value="Change"><br><br><br>
	</form>

	<p><h3><strong>Вывести таблицу из БД: </strong></h3></p>
	<form method="post" action="index.php">
		<input type="submit" name="but3" value="Вывести таблицу">
	</form>

<pre>
<?php

$link = mysqli_connect('localhost', 'root', '', 'my_first_bd');
if(isset($_POST['but']))
{
	$FIO = $_POST['lbl2']; 
	$Age = $_POST['lbl3'];
	$Country = $_POST['lbl4'];

	$query = "INSERT INTO `someinfo` (`FIO`, `Age`, `Country`) VALUES ('$FIO','$Age', '$Country')";
 	$result = mysqli_query($link, $query) or die ("Ошибка " . mysqli_error($link)); 
    if($result)
    {
        echo "<span style='color:blue;'>Данные добавлены</span>";
    }
    mysqli_close($link);
}

if(isset($_POST['but1']))
{
	$idDel = $_POST['lblID'];
	$query1 = "DELETE FROM `someinfo` WHERE `someinfo`.`id` = $idDel";
	$result1 = mysqli_query($link, $query1) or die ("Ошибка " . mysqli_error($link)); 
    if($result1)
    {
        echo "<span style='color:red;'>Запись удалена</span>";
    }
    mysqli_close($link);
}

if(isset($_POST['but2']))
{
	$idChange = $_POST['lblIDToChange'];
	$FIOChange = $_POST['lblFIOToChange'];
	$AgeChange = $_POST['lblAgeToChange'];
	$CountryChange = $_POST['lblCountryToChange'];

	$query2 = "UPDATE `someinfo` SET `FIO` = '$FIOChange', `Age` = '$AgeChange', `Country` = '$CountryChange' WHERE `someinfo`.`id` = $idChange";
	$result2 = mysqli_query($link, $query2) or die ("Ошибка " . mysqli_error($link)); 
    if($result2)
    {
        echo "<span style='color:green;'>Запись отредактирована</span>";
    }
    mysqli_close($link);
}

if(isset($_POST['but3']))
{
	$sql = "SELECT * FROM `SomeInfo`";
	$result = mysqli_query($link, $sql);
	$data = mysqli_fetch_all($result, MYSQLI_ASSOC);
	print_r($data);
}

?>
</pre>
</body>
</html>