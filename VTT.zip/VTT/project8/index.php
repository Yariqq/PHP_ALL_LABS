<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Send mail</title>
</head>
<body>
	<form method="post" action="index.php">
		<input type="text" name="lblMail" placeholder="mail"><br><br>
		<input type="text" name="lblText" placeholder="text"><br><br>
		<input type="submit" name="but" value="Send">
	</form>

<?php
if (isset($_POST['but']))
{
	$result = mail($_POST['lblMail'], 'Privet', $_POST['lblText']);
}


?>

</body>
</html>